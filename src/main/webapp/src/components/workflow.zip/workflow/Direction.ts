export default class Direction {
    public static DOWN: 2;
    public static LEFT: 3;
    public static RIGHT: 1;
    public static UP: 0;
}