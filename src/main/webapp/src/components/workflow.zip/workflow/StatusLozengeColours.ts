export default class StatusLozengeColours {
    getBackgroundColour(options) {
        // TODO: chanfe based o
        return '#4a6785'
    }
}